"""Real service/client processes with a test-only device, never physical MMIO."""
import os, socket, struct, subprocess, sys, tempfile, time
from pathlib import Path
with tempfile.TemporaryDirectory(prefix='dmotor-service-') as tmp:
    root=Path(tmp);env={**os.environ,'DMOTOR_TEST_DIRECTORY':tmp}
    config=root/'motors.conf'
    config.write_text((Path(__file__).resolve().parents[1]/'config/output-validation.conf').read_text())
    powered=len(sys.argv)>3 and sys.argv[3]=="--powered"
    direct=len(sys.argv)>3 and sys.argv[3] in ("--direct", "--powered")
    if powered:
        config.write_text((Path(__file__).resolve().parents[1]/'config/powered-direct-duty.conf').read_text())
    commissioning=len(sys.argv)>3
    log=open(root/'service.log','w+')
    daemon=subprocess.Popen([sys.argv[1],'--powered-commissioning' if powered else '--externally-inhibited','/dev/fake',str(config)]+(['--direct-duty','50','10'] if direct else ['--commissioning'] if commissioning else []),env=env,stdout=log,stderr=log)
    def connect():
        s=socket.socket(socket.AF_UNIX,socket.SOCK_SEQPACKET);s.settimeout(2);s.connect(str(root/'control.sock'));return s
    def request(s,op,mask=0,vel=(0,0,0,0)):
        s.send(struct.pack('<IIIiiii',1,op,mask,*vel));data=s.recv(192);assert len(data)==192
        return struct.unpack('<IIII',data[:16])
    def target(s):
        return request(s,11,1,(16384,0,0,0)) if direct else request(s,4,1,(1000,0,0,0))
    try:
        for _ in range(200):
            if (root/'control.sock').exists(): break
            assert daemon.poll() is None
            time.sleep(.01)
        s=connect();assert request(s,0)[1]==1
        second=connect();assert second.recv(192)==b'';second.close()
        assert request(s,2)[1]==1
        assert request(s,3,1)[1]==1
        assert target(s)[1]==1
        time.sleep(.04);assert request(s,1)[3]>0
        if powered:
            # Keep lease alive and repeatedly update duty: original pulse deadline wins.
            start=time.monotonic()
            while time.monotonic()-start<.75:
                assert target(s)[1]==1
                time.sleep(.04)
            while time.monotonic()-start<1.1:
                assert request(s,0)[1]==1
                time.sleep(.04)
            assert request(s,1)[2]&1==0  # disabled by pulse expiry
            assert target(s)[1]==0       # no restart without rearm
            assert request(s,2)[1]==1
            assert request(s,3,1)[1]==1
            assert target(s)[1]==1
            time.sleep(.02)
            assert request(s,11,1,(0,0,0,0))[1]==1
            assert request(s,1)[2]&1==0
            assert target(s)[1]==0
        # Inactivity expires ownership, closes client and leaves HALT latched.
        time.sleep(.6);assert s.recv(192)==b'';s.close()
        s=connect();assert request(s,1)[2]&(1<<18)
        assert request(s,3,1)[1]==0
        assert request(s,2)[1]==1
        assert request(s,3,1)[1]==1
        s.close();time.sleep(.03)
        s=connect();assert request(s,1)[2]&(1<<18)
        request(s,8);s.close();time.sleep(.03)
        # Interactive event loop renews while idle; ! interrupts partial input.
        menu=subprocess.Popen([sys.argv[2]],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        menu.stdin.write('r\ne\n');menu.stdin.flush();time.sleep(.7)
        assert menu.poll() is None
        menu.stdin.write('v 12!\nq\n');menu.stdin.flush()
        out,err=menu.communicate(timeout=3)
        assert menu.returncode==0,(out,err)
        assert 'HALT confirmed' in out and 'HALT ALL confirmed' in out,(out,err)
        # EOF must also take the acknowledged HALT exit path.
        menu=subprocess.run([sys.argv[2]],env=env,input='',capture_output=True,text=True,timeout=3)
        assert menu.returncode==0,(menu.stdout,menu.stderr)
        assert 'HALT ALL confirmed' in menu.stdout
        # A killed client cannot run its exit handler: the service must inhibit.
        menu=subprocess.Popen([sys.argv[2]],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        menu.stdin.write('r\ne\n');menu.stdin.flush();time.sleep(.1)
        menu.kill();menu.communicate(timeout=3);time.sleep(.03)
        s=connect();assert request(s,1)[2]&(1<<18)
        assert request(s,3,1)[1]==0
        request(s,8);s.close()
        for op in (9,10):
            time.sleep(.03);s=connect()
            assert request(s,2)[1]==1
            assert request(s,3,1)[1]==1
            assert target(s)[1]==1
            time.sleep(.03)
            assert request(s,op)[1]==int(commissioning and not powered)
            if commissioning and not powered:
                # The fixture has no FPGA expiry timers: independent host fallback
                # must disconnect before the 500 ms client lease.
                time.sleep(.2);assert s.recv(192)==b'';s.close()
                s=connect();assert request(s,1)[2]&(1<<18)
                assert request(s,3,1)[1]==0
            request(s,8);s.close()
        print('PASS: exclusive client, lease expiry, disconnect, stale enable rejection, idle menu lease, partial-input HALT, quit, EOF and killed client')
    finally:
        daemon.terminate()
        try: daemon.communicate(timeout=3)
        except subprocess.TimeoutExpired: daemon.kill();daemon.communicate()

    log.flush();log.seek(0);evidence=log.read();log.close()
    if commissioning and not powered:
        assert 'inject_target' in evidence and 'inject_watchdog' in evidence
        assert 'Injection deadline: FPGA trip not observed; host HALT' in evidence
